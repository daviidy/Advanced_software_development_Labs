package edu.mum.cs.cs525.labs.skeleton;

public interface IInterest {
    double calculateInterest(double balance);
}
