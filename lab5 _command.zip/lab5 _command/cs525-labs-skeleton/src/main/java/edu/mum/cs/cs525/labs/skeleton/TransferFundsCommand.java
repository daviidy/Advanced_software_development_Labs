package edu.mum.cs.cs525.labs.skeleton;

public class TransferFundsCommand implements Command{
    @Override
    public void execute() {

    }

    @Override
    public void undo() {

    }
}
