package edu.mum.cs.cs525.labs.skeleton;

public enum LogLevel {
    DEBUG, ERROR, FATAL, INFO, TRACE, WARNING
}
