package edu.mum.cs.cs525.labs.skeleton;

public interface Logger {
    void log(LogLevel logLevel, String message);
}
