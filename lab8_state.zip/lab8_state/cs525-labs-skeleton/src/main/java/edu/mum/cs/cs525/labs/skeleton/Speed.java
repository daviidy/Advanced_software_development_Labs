package edu.mum.cs.cs525.labs.skeleton;

public enum Speed {
    LOW,
    MEDIUM,
    HIGH
}
