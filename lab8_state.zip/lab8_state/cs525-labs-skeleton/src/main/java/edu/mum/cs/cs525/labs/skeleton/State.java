package edu.mum.cs.cs525.labs.skeleton;

public interface State {
    void pullgreen();
    void pullred();
}
