package edu.mum.cs.cs525.labs.skeleton;

public interface Complex {
    void veryComplicatedTask();
    void anotherTask();
}
